﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment1ClassLibrary
{
    public class PageException : Exception
    {
        public PageException() : base("Page number should between 11 and 1000 pages ") { }

        public PageException(string message) : base(message) { }
        public PageException(string message, Exception inner) : base(message, inner) { }
    }
}
