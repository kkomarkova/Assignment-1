﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Threading.Channels;

namespace Assignment1ClassLibrary
{
    public class Book
    {
        /// <summary>
        /// Instance fields of Book class
        /// </summary>
        private string _title;
        private string _author;
        private int _pagenumber;
        private string _isbn;
        /// <summary>
        /// Default constructor of class Book
        /// </summary>
        public Book()
        {

        }
        /// <summary>
        /// Constructor of Book class, which takes 4 parameters
        /// </summary>
        /// <param name="Isbn13"></param>
        /// <param name="Author"></param>
        /// <param name="Title"></param>
        /// <param name="PageNumber"></param>
        public Book(string Isbn13, string Author, String Title, int PageNumber)
        {
            _author = Author;
            _title = Title;
            _pagenumber = PageNumber;
            _isbn = Isbn13;
        }

        /// <summary>
        /// Property title minimum 2 characters long
        /// </summary>

        public string Title
        {
            get { return _title; }
            set
            {
                if (value.Length < 2)
                {
                    throw new TitleException();
                }
                _title = value;
            }
        }

        /// <summary>
        /// Property Author
        /// </summary>

        public string Author
        {
            get { return _author; }
            set { _author = value; }
        }

        /// <summary>
        /// Property page number 10 < pagenumber <= 1000
        /// </summary>

        public int PageNumber
        {
            get { return _pagenumber; }
            set
            {
                if (value < 10 || value >= 1000 )
                {
                    throw new PageException();
                }
                _pagenumber = value;
            }
        }

        /// <summary>
        /// Property Isbn needs to have exactly 13 characters
        /// </summary>
        public string Isbn
        {
            get { return _isbn; }
            set
            {
                if (value.Length != 13)
                {
                    throw new IsbnException("The Isbn should have 13 characters, please try it again");
                }
                _isbn = value;
            }
        }



    }
}
