﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment1ClassLibrary
{
    public class TitleException : Exception
    {
        public TitleException() : base("Title should be at least 2 characters long") { }

        public TitleException(string message) : base(message) { }

        public TitleException(string message, Exception inner) : base(message, inner) { }
    }
}
