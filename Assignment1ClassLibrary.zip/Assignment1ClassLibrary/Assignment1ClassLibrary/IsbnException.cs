﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment1ClassLibrary
{
    public class IsbnException : Exception
    {
        public IsbnException() : base(" Isbn should be 13 characters long") { }

        public IsbnException(string message) : base(message) { }
        public IsbnException(string message, Exception inner) : base(message, inner) { }

    }
}
