using Microsoft.VisualStudio.TestTools.UnitTesting;
using Assignment1ClassLibrary;
using System;

namespace Assigment1UnitTest
{
    [TestClass]
    public class UnitTest1
    {
    /// <summary>
    /// We are testing if the TitleException works
    /// </summary>
        [TestMethod]
        [ExpectedException(typeof(TitleException))]
        public void TitleTestException()
        {
            // Arrange
            Book b = new Book();
            string bookTitle = "b";

            // Act
            b.Title = bookTitle;

            //Assert
            Assert.AreEqual(bookTitle, b.Title);
        }
        /// <summary>
        /// We are testing if the PageException works
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(PageException))]
        public void PageTestException()
        {
            // Arrange
            Book b = new Book();
            int pagenumber = 1500;

            // Act
            b.PageNumber = pagenumber;

            //Assert
            Assert.AreEqual(pagenumber, b.PageNumber);
        }
        /// <summary>
        /// We are testing if the IsbnException works
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof(IsbnException))]
        public void IsbnException()
        {
            // Arrange
            Book b = new Book();
            string isbn = "12345678";

            // Act
            b.Isbn = isbn;

            //Assert
            Assert.AreEqual(isbn, b.Isbn);
        }
        /// <summary>
        /// We are testing if the author property works
        /// </summary>
        [TestMethod]
        
        public void AuthorTest()
        {
            // Arrange
            Book b = new Book();
            string name = "John";

            // Act
            b.Author = name;

            //Assert
            Assert.AreEqual(name, b.Author);
        }
        /// <summary>
        /// We are testing if the Isbn property works
        /// </summary>
        [TestMethod]

        public void IsbnTest()
        {
            // Arrange
            Book b = new Book();
            string isbn = "1234567890123";

            // Act
            b.Isbn = isbn;

            //Assert
            Assert.AreEqual(isbn, b.Isbn);
        }
        /// <summary>
        /// We are testing if the title property works
        /// </summary>
        [TestMethod]

        public void TitleTest()
        {
            // Arrange
            Book b = new Book();
            string title = " The Great Gatsby";

            // Act
            b.Title = title;

            //Assert
            Assert.AreEqual(title, b.Title);
        }

    }
}
